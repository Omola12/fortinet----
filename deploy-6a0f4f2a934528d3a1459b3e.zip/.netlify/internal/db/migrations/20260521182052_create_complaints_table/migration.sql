CREATE TABLE "complaints" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"subject" text NOT NULL,
	"category" text NOT NULL,
	"message" text NOT NULL,
	"status" text DEFAULT 'Pending' NOT NULL,
	"reply" text DEFAULT '',
	"reply_date" text DEFAULT '',
	"created_at" timestamp DEFAULT now() NOT NULL
);
