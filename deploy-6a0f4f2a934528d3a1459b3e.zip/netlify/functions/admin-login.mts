import type { Config, Context } from "@netlify/functions";
import crypto from "crypto";

export default async function handler(req: Request, context: Context): Promise<Response> {
  const headers = { "Content-Type": "application/json" };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  }

  try {
    const { username, password } = await req.json();

    const adminUsername = process.env.ADMIN_USERNAME || "fortinet";
    const adminPassword = process.env.ADMIN_PASSWORD || "fortinet123";

    if (username === adminUsername && password === adminPassword) {
      const token = crypto
        .createHash("sha256")
        .update(adminUsername + ":" + adminPassword)
        .digest("hex");
      return new Response(JSON.stringify({ success: true, token }), { status: 200, headers });
    }

    return new Response(
      JSON.stringify({ success: false, error: "Invalid credentials" }),
      { status: 401, headers }
    );
  } catch (err) {
    console.error("admin-login error:", err);
    return new Response(JSON.stringify({ success: false, error: "Internal server error" }), {
      status: 500,
      headers,
    });
  }
}

export const config: Config = {
  path: "/api/admin/login",
};
