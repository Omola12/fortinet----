import type { Config, Context } from "@netlify/functions";
import { db } from "../../db/index.js";
import { complaints } from "../../db/schema.js";
import { desc } from "drizzle-orm";
import crypto from "crypto";

function verifyAdminToken(req: Request): boolean {
  const adminUsername = process.env.ADMIN_USERNAME || "fortinet";
  const adminPassword = process.env.ADMIN_PASSWORD || "fortinet123";
  const expected = crypto
    .createHash("sha256")
    .update(adminUsername + ":" + adminPassword)
    .digest("hex");
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return false;
  return authHeader.replace("Bearer ", "") === expected;
}

export default async function handler(req: Request, context: Context): Promise<Response> {
  const headers = { "Content-Type": "application/json" };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  try {
    if (req.method === "GET") {
      if (!verifyAdminToken(req)) {
        return new Response(JSON.stringify({ success: false, error: "Unauthorized" }), {
          status: 401,
          headers,
        });
      }
      const all = await db.select().from(complaints).orderBy(desc(complaints.created_at));
      return new Response(JSON.stringify({ success: true, complaints: all }), { status: 200, headers });
    }

    if (req.method === "POST") {
      const body = await req.json();
      const { name, email, subject, category, message } = body;

      if (!name || !email || !subject || !category || !message) {
        return new Response(
          JSON.stringify({ success: false, error: "All fields are required" }),
          { status: 400, headers }
        );
      }

      const id =
        "FTNT-" +
        Date.now() +
        "-" +
        Math.random().toString(36).substring(2, 10).toUpperCase();

      await db.insert(complaints).values({
        id,
        name,
        email,
        subject,
        category,
        message,
        status: "Pending",
        reply: "",
        reply_date: "",
      });

      return new Response(JSON.stringify({ success: true, id }), { status: 201, headers });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  } catch (err) {
    console.error("complaints error:", err);
    return new Response(JSON.stringify({ success: false, error: "Internal server error" }), {
      status: 500,
      headers,
    });
  }
}

export const config: Config = {
  path: "/api/complaints",
};
