import type { Config, Context } from "@netlify/functions";
import { db } from "../../db/index.js";
import { complaints } from "../../db/schema.js";
import { eq } from "drizzle-orm";
import crypto from "crypto";

function verifyAdminToken(req: Request): boolean {
  const adminUsername = process.env.ADMIN_USERNAME || "fortinet";
  const adminPassword = process.env.ADMIN_PASSWORD || "fortinet123";
  const expected = crypto
    .createHash("sha256")
    .update(adminUsername + ":" + adminPassword)
    .digest("hex");
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return false;
  return authHeader.replace("Bearer ", "") === expected;
}

export default async function handler(req: Request, context: Context): Promise<Response> {
  const headers = { "Content-Type": "application/json" };
  const id = context.params.id;

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  try {
    if (req.method === "GET") {
      const [complaint] = await db.select().from(complaints).where(eq(complaints.id, id));
      return new Response(
        JSON.stringify({ success: true, complaint: complaint || null }),
        { status: 200, headers }
      );
    }

    if (req.method === "DELETE") {
      if (!verifyAdminToken(req)) {
        return new Response(JSON.stringify({ success: false, error: "Unauthorized" }), {
          status: 401,
          headers,
        });
      }
      await db.delete(complaints).where(eq(complaints.id, id));
      return new Response(JSON.stringify({ success: true }), { status: 200, headers });
    }

    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  } catch (err) {
    console.error("complaint-detail error:", err);
    return new Response(JSON.stringify({ success: false, error: "Internal server error" }), {
      status: 500,
      headers,
    });
  }
}

export const config: Config = {
  path: "/api/complaints/:id",
};
