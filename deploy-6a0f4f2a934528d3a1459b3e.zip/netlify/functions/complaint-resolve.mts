import type { Config, Context } from "@netlify/functions";
import { db } from "../../db/index.js";
import { complaints } from "../../db/schema.js";
import { eq } from "drizzle-orm";
import crypto from "crypto";

function verifyAdminToken(req: Request): boolean {
  const adminUsername = process.env.ADMIN_USERNAME || "fortinet";
  const adminPassword = process.env.ADMIN_PASSWORD || "fortinet123";
  const expected = crypto
    .createHash("sha256")
    .update(adminUsername + ":" + adminPassword)
    .digest("hex");
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return false;
  return authHeader.replace("Bearer ", "") === expected;
}

export default async function handler(req: Request, context: Context): Promise<Response> {
  const headers = { "Content-Type": "application/json" };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204 });
  }

  if (req.method !== "PUT") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  }

  if (!verifyAdminToken(req)) {
    return new Response(JSON.stringify({ success: false, error: "Unauthorized" }), {
      status: 401,
      headers,
    });
  }

  try {
    const id = context.params.id;

    await db
      .update(complaints)
      .set({ status: "Resolved" })
      .where(eq(complaints.id, id));

    return new Response(JSON.stringify({ success: true }), { status: 200, headers });
  } catch (err) {
    console.error("complaint-resolve error:", err);
    return new Response(JSON.stringify({ success: false, error: "Internal server error" }), {
      status: 500,
      headers,
    });
  }
}

export const config: Config = {
  path: "/api/complaints/:id/resolve",
};
