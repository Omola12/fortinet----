import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const complaints = pgTable("complaints", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  category: text("category").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("Pending"),
  reply: text("reply").default(""),
  reply_date: text("reply_date").default(""),
  created_at: timestamp("created_at").notNull().defaultNow(),
});
