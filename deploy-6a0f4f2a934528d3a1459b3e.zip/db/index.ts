import { getConnectionString } from "@netlify/database";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "./schema.js";

export const db = drizzle(getConnectionString(), { schema });
